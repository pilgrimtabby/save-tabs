"""See README.md and the documentation in each module for a detailed
explanation of this package's purpose and operation.
"""
import os
import sys


# Allow importing between modules without issues.
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
